const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const ADMIN_PASSWORD = 'VectorX@1523';
const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');
const REPORTS_FILE = path.join(__dirname, '..', 'data', 'reports.json');
const PICKUPS_FILE = path.join(__dirname, '..', 'data', 'pickups.json');

function readJSON(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (e) {
    return [];
  }
}

// Admin Login
router.post('/login', (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    req.session.isAdmin = true;
    return res.json({ success: true, message: 'Admin login successful' });
  }
  res.status(401).json({ success: false, message: 'Invalid admin password' });
});

// Admin auth middleware
function adminAuth(req, res, next) {
  if (!req.session.isAdmin) {
    return res.status(403).json({ success: false, message: 'Admin access required' });
  }
  next();
}

// Dashboard stats
router.get('/stats', adminAuth, (req, res) => {
  const users = readJSON(USERS_FILE);
  const reports = readJSON(REPORTS_FILE);
  const pickups = readJSON(PICKUPS_FILE);
  const totalPoints = users.reduce((sum, u) => sum + (u.points || 0), 0);

  res.json({
    success: true,
    stats: {
      totalUsers: users.length,
      totalReports: reports.length,
      totalPickups: pickups.length,
      totalPoints
    }
  });
});

// All users
router.get('/users', adminAuth, (req, res) => {
  const users = readJSON(USERS_FILE).map(u => ({
    id: u.id,
    name: u.name,
    email: u.email,
    mobile: u.mobile,
    points: u.points || 0,
    createdAt: u.createdAt
  }));
  res.json({ success: true, users });
});

// All reports
router.get('/reports', adminAuth, (req, res) => {
  const reports = readJSON(REPORTS_FILE);
  res.json({ success: true, reports });
});

// All pickups
router.get('/pickups', adminAuth, (req, res) => {
  const pickups = readJSON(PICKUPS_FILE);
  res.json({ success: true, pickups });
});

// Update pickup status
router.put('/pickups/:id', adminAuth, (req, res) => {
  const pickups = readJSON(PICKUPS_FILE);
  const idx = pickups.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Pickup not found' });

  pickups[idx].status = req.body.status;
  fs.writeFileSync(PICKUPS_FILE, JSON.stringify(pickups, null, 2));
  res.json({ success: true, pickup: pickups[idx] });
});

// Logout
router.post('/logout', (req, res) => {
  req.session.isAdmin = false;
  res.json({ success: true });
});

module.exports = router;
