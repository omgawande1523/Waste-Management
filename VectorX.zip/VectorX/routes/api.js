const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');
const REPORTS_FILE = path.join(__dirname, '..', 'data', 'reports.json');
const PICKUPS_FILE = path.join(__dirname, '..', 'data', 'pickups.json');

const HF_API_KEY = process.env.HF_API_KEY;

// Multer setup for image uploads
const storage = multer.memoryStorage();
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

function readJSON(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
  catch (e) { return []; }
}
function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Auth middleware
function authRequired(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, message: 'Login required' });
  }
  next();
}

// ====================== WASTE CATEGORY MAPPING ======================
const wasteCategoryMap = {
  // Plastic — sorted longest-first so multi-word matches hit before single-word
  'water bottle': 'Plastic', 'plastic bag': 'Plastic', 'plastic bottle': 'Plastic',
  'pop bottle': 'Plastic', 'soda bottle': 'Plastic',
  'bottle': 'Plastic', 'cup': 'Plastic', 'container': 'Plastic', 'wrapper': 'Plastic',
  'straw': 'Plastic', 'bucket': 'Plastic', 'jug': 'Plastic', 'pitcher': 'Plastic',
  'packet': 'Plastic', 'toy': 'Plastic', 'pen': 'Plastic', 'lighter': 'Plastic',
  'comb': 'Plastic', 'toothbrush': 'Plastic', 'tupperware': 'Plastic', 'bag': 'Plastic',
  'tub': 'Plastic', 'diaper': 'Plastic', 'polythene': 'Plastic', 'styrofoam': 'Plastic',
  'plastic': 'Plastic', 'nylon': 'Plastic', 'pvc': 'Plastic', 'polycarbonate': 'Plastic',

  // Organic
  'banana': 'Organic', 'apple': 'Organic', 'orange': 'Organic', 'mango': 'Organic',
  'food': 'Organic', 'leaf': 'Organic', 'flower': 'Organic', 'bread': 'Organic',
  'fruit': 'Organic', 'vegetable': 'Organic', 'meat': 'Organic', 'egg': 'Organic',
  'wood': 'Organic', 'paper': 'Organic', 'cardboard': 'Organic', 'cotton': 'Organic',
  'tea': 'Organic', 'coffee': 'Organic', 'rice': 'Organic', 'corn': 'Organic',
  'seed': 'Organic', 'nut': 'Organic', 'peel': 'Organic', 'husk': 'Organic',
  'grass': 'Organic', 'straw': 'Organic', 'hay': 'Organic', 'compost': 'Organic',
  'tissue': 'Organic', 'napkin': 'Organic', 'bamboo': 'Organic', 'jute': 'Organic',

  // Metal
  'beer can': 'Metal', 'soda can': 'Metal', 'tin can': 'Metal', 'aluminum can': 'Metal',
  'can': 'Metal', 'tin': 'Metal', 'foil': 'Metal', 'wire': 'Metal',
  'nail': 'Metal', 'screw': 'Metal', 'key': 'Metal', 'coin': 'Metal',
  'fork': 'Metal', 'knife': 'Metal', 'spoon': 'Metal', 'pan': 'Metal',
  'pot': 'Metal', 'iron': 'Metal', 'steel': 'Metal', 'aluminum': 'Metal',
  'copper': 'Metal', 'brass': 'Metal', 'bolt': 'Metal', 'wrench': 'Metal',
  'chain': 'Metal', 'pipe': 'Metal', 'utensil': 'Metal', 'cutlery': 'Metal',
  'metal': 'Metal',

  // Glass
  'wine glass': 'Glass', 'beer glass': 'Glass',
  'glass': 'Glass', 'mirror': 'Glass', 'window': 'Glass', 'jar': 'Glass',
  'vase': 'Glass', 'bulb': 'Glass', 'lens': 'Glass', 'goblet': 'Glass',
  'carafe': 'Glass', 'decanter': 'Glass', 'flask': 'Glass', 'beaker': 'Glass',
  'crystal': 'Glass', 'tumbler': 'Glass',

  // Hazardous — includes electronics / e-waste
  'battery': 'Hazardous', 'chemical': 'Hazardous', 'paint': 'Hazardous',
  'syringe': 'Hazardous', 'medicine': 'Hazardous', 'pesticide': 'Hazardous',
  'cleaner': 'Hazardous', 'acid': 'Hazardous', 'bleach': 'Hazardous',
  'fluorescent': 'Hazardous', 'thermometer': 'Hazardous', 'motor oil': 'Hazardous',
  'electronics': 'Hazardous', 'e-waste': 'Hazardous', 'circuit': 'Hazardous',
  'motherboard': 'Hazardous', 'laptop': 'Hazardous', 'computer': 'Hazardous',
  'phone': 'Hazardous', 'tablet': 'Hazardous', 'monitor': 'Hazardous',
  'television': 'Hazardous', 'printer': 'Hazardous', 'keyboard': 'Hazardous',
  'mouse': 'Hazardous', 'charger': 'Hazardous', 'cable': 'Hazardous',
  'cell phone': 'Hazardous', 'cellular telephone': 'Hazardous',
  'remote control': 'Hazardous', 'remote': 'Hazardous',
  'solvent': 'Hazardous', 'aerosol': 'Hazardous', 'fertilizer': 'Hazardous'
};

const categoryEmoji = {
  'Plastic': '🔵', 'Organic': '🟢', 'Metal': '⚪',
  'Glass': '🟣', 'Hazardous': '🔴', 'Unknown': '🟡'
};

const disposalInstructions = {
  'Plastic': 'Rinse and clean the plastic item. Remove labels if possible. Check the recycling number (♻️ 1-7) on the bottom. Place in the recycling bin marked for plastics. Avoid mixing with food-contaminated plastics.',
  'Organic': 'Place in a compost bin or organic waste container. Can be used for composting to create nutrient-rich soil. Avoid mixing with non-biodegradable waste. Composting reduces methane emissions from landfills.',
  'Metal': 'Clean the metal item and remove any non-metal parts. Crush aluminum cans to save space. Place in the metal recycling bin. Metal can be recycled infinitely without quality loss!',
  'Glass': 'Rinse the glass item. Remove caps or lids (recycle separately). Sort by color if possible. Place in the glass recycling bin. Do NOT mix broken glass with regular waste — wrap in newspaper first.',
  'Hazardous': '⚠️ Do NOT dispose in regular waste! Take to a designated hazardous waste or e-waste collection center. Keep in original container if possible. Many electronics stores accept e-waste. Contact local waste authority for pickup.',
  'Unknown': 'We could not determine the exact category with high confidence. As a safe default: do NOT mix with regular waste. Check with your local waste management authority or bring to a sorting facility for proper disposal.'
};

const reuseSuggestions = {
  'Plastic': ['Use as a planter for small plants 🌱', 'Create DIY organizers or pen holders', 'Repurpose bottles as bird feeders', 'Use for storing small hardware items'],
  'Organic': ['Start a compost pile for garden use 🌿', 'Use citrus peels as natural air fresheners', 'Dry and grind eggshells for garden calcium', 'Create natural dyes from vegetable waste'],
  'Metal': ['Use tin cans as herb planters 🌿', 'Create wind chimes or garden art', 'Bend into cookie cutters', 'Organize nuts & bolts in labeled cans'],
  'Glass': ['Use jars for food storage & meal prep 🫙', 'Create decorative candle holders', 'Build small terrariums for plants', 'Use as flower vases with painted designs'],
  'Hazardous': ['Do not reuse hazardous materials ⚠️', 'Switch to rechargeable batteries', 'Donate working electronics to charities', 'Choose eco-friendly cleaning products'],
  'Unknown': ['Research the item material before reusing', 'Contact local recycling centers for guidance', 'Consider donating if the item still works']
};

function classifyWaste(label) {
  const lowerLabel = label.toLowerCase();
  // Try multi-word matches first (longest keyword first)
  const sortedEntries = Object.entries(wasteCategoryMap)
    .sort((a, b) => b[0].length - a[0].length);
  for (const [keyword, category] of sortedEntries) {
    if (lowerLabel.includes(keyword)) {
      return category;
    }
  }
  return 'Unknown';
}

// ====================== SCANNER ENDPOINT ======================
router.post('/scan', authRequired, upload.single('image'), async (req, res) => {
  try {
    let imageBuffer;

    if (req.file) {
      // Binary upload via FormData (preferred path)
      imageBuffer = req.file.buffer;
    } else if (req.body.image) {
      // Base64 fallback from camera capture
      const base64Data = req.body.image.replace(/^data:image\/\w+;base64,/, '');
      imageBuffer = Buffer.from(base64Data, 'base64');
    } else {
      return res.status(400).json({ success: false, message: 'No image provided' });
    }

    // Try Hugging Face API
    if (HF_API_KEY) {
      try {
        const hfResponse = await fetch(
          'https://api-inference.huggingface.co/models/google/vit-base-patch16-224',
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${HF_API_KEY}`,
              'Content-Type': 'application/octet-stream'
            },
            body: imageBuffer,
            timeout: 30000
          }
        );

        // Handle model loading (503)
        if (hfResponse.status === 503) {
          const loadInfo = await hfResponse.json().catch(() => ({}));
          const waitTime = loadInfo.estimated_time ? Math.ceil(loadInfo.estimated_time) : 20;
          return res.json({
            success: false,
            modelLoading: true,
            message: `AI model is warming up. Please try again in ~${waitTime} seconds.`
          });
        }

        if (hfResponse.ok) {
          const results = await hfResponse.json();
          if (Array.isArray(results) && results.length > 0) {
            // Build top-3 enriched predictions
            const top3 = results.slice(0, 3).map((r, idx) => {
              const cat = classifyWaste(r.label);
              return {
                rank: idx + 1,
                label: r.label,
                confidence: `${(r.score * 100).toFixed(1)}%`,
                confidenceRaw: r.score,
                category: cat,
                emoji: categoryEmoji[cat] || '🟡'
              };
            });

            const best = top3[0];
            const isLowConfidence = best.confidenceRaw < 0.25;

            return res.json({
              success: true,
              result: {
                detectedObject: best.label,
                confidence: best.confidence,
                category: best.category,
                categoryEmoji: best.emoji,
                isLowConfidence,
                disposal: disposalInstructions[best.category],
                reuseSuggestions: reuseSuggestions[best.category],
                topPredictions: top3,
                allResults: results.slice(0, 5).map(r => ({
                  label: r.label,
                  confidence: `${(r.score * 100).toFixed(1)}%`,
                  category: classifyWaste(r.label)
                }))
              }
            });
          }
        } else {
          const errBody = await hfResponse.text().catch(() => '');
          console.error(`HF API returned ${hfResponse.status}: ${errBody}`);
        }
      } catch (apiError) {
        console.error('HF API error:', apiError.message);
      }
    }

    // ── Fallback response (no API key or API failed) ──
    const fallbackItems = [
      { label: 'water bottle', confidence: '87.3%', category: 'Plastic' },
      { label: 'banana peel', confidence: '82.1%', category: 'Organic' },
      { label: 'aluminum can', confidence: '79.5%', category: 'Metal' },
      { label: 'glass jar', confidence: '75.8%', category: 'Glass' },
      { label: 'cardboard box', confidence: '73.2%', category: 'Organic' },
      { label: 'old battery', confidence: '69.9%', category: 'Hazardous' }
    ];
    const fb = fallbackItems[Math.floor(Math.random() * fallbackItems.length)];

    res.json({
      success: true,
      isFallback: true,
      result: {
        detectedObject: fb.label,
        confidence: fb.confidence,
        category: fb.category,
        categoryEmoji: categoryEmoji[fb.category] || '🟡',
        isLowConfidence: false,
        disposal: disposalInstructions[fb.category],
        reuseSuggestions: reuseSuggestions[fb.category],
        topPredictions: [{
          rank: 1,
          label: fb.label,
          confidence: fb.confidence,
          category: fb.category,
          emoji: categoryEmoji[fb.category] || '🟡'
        }],
        allResults: [{ label: fb.label, confidence: fb.confidence, category: fb.category }]
      }
    });

  } catch (error) {
    console.error('Scan error:', error);
    res.status(500).json({ success: false, message: 'Failed to analyze image. Please try again.' });
  }
});

// ====================== CHATBOT ENDPOINT ======================
router.post('/chat', authRequired, async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message) {
      return res.status(400).json({ success: false, message: 'Message is required' });
    }

    // Try Hugging Face API — google/flan-t5-base (text2text-generation)
    if (HF_API_KEY) {
      try {
        // Build context from recent conversation history
        let contextBlock = '';
        if (history && history.length > 0) {
          const recent = history.slice(-10);
          contextBlock = recent.map(m =>
            m.role === 'user' ? `User: ${m.content}` : `Assistant: ${m.content}`
          ).join('\n') + '\n';
        }

        const prompt = `You are a smart, helpful assistant for waste management in India. Answer naturally like ChatGPT. Give helpful, human-like responses including reuse ideas, disposal tips, and sustainability advice.

${contextBlock}User: ${message}
Assistant:`;

        const hfResponse = await fetch(
          'https://api-inference.huggingface.co/models/google/flan-t5-base',
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${HF_API_KEY}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              inputs: prompt,
              parameters: {
                max_new_tokens: 300,
                temperature: 0.7,
                do_sample: true,
                top_p: 0.9
              }
            }),
            timeout: 30000
          }
        );

        // Handle model loading
        if (hfResponse.status === 503) {
          console.log('flan-t5-base loading, falling back');
        } else if (hfResponse.ok) {
          const result = await hfResponse.json();
          let reply = '';
          if (Array.isArray(result) && result[0]?.generated_text) {
            reply = result[0].generated_text.trim();
          } else if (result?.generated_text) {
            reply = result.generated_text.trim();
          }
          // Only use API reply if it's meaningful
          if (reply && reply.length > 15 && !reply.toLowerCase().startsWith('user:')) {
            return res.json({ success: true, reply });
          }
        } else {
          const errBody = await hfResponse.text().catch(() => '');
          console.error(`Chat API returned ${hfResponse.status}: ${errBody}`);
        }
      } catch (apiError) {
        console.error('Chat API error:', apiError.message);
      }
    }

    // ── Intelligent fallback system ──
    const reply = generateSmartFallback(message, history);
    res.json({ success: true, reply, isFallback: true });

  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ success: false, message: 'Chat service is temporarily unavailable. Please try again.' });
  }
});

// ── Smart fallback response generator ──
function generateSmartFallback(message, history) {
  const msg = message.toLowerCase().trim();
  const isHindi = /[\u0900-\u097F]/.test(message);
  const isFirstMessage = !history || history.length <= 1;

  if (isHindi || msg.includes('namaste') || msg.includes('hindi')) {
    const hindiResponses = [
      '\u0928\u092E\u0938\u094D\u0924\u0947! \uD83D\uDE4F \u092E\u0948\u0902 VectorX AI \u0939\u0942\u0902, \u0906\u092A\u0915\u093E \u0915\u091A\u0930\u093E \u092A\u094D\u0930\u092C\u0902\u0927\u0928 \u0938\u0939\u093E\u092F\u0915\u0964 \u092E\u0948\u0902 \u0906\u092A\u0915\u0940 \u0915\u091A\u0930\u0947 \u0915\u094B \u0938\u0939\u0940 \u0924\u0930\u0940\u0915\u0947 \u0938\u0947 \u0928\u093F\u092A\u091F\u093E\u0928 \u0915\u0930\u0928\u0947, \u0930\u0940\u0938\u093E\u0907\u0915\u094D\u0932\u093F\u0902\u0917, \u0914\u0930 \u0915\u092E\u094D\u092A\u094B\u0938\u094D\u091F\u093F\u0902\u0917 \u092E\u0947\u0902 \u092E\u0926\u0926 \u0915\u0930 \u0938\u0915\u0924\u093E \u0939\u0942\u0902\u0964 \u0915\u0943\u092A\u092F\u093E \u0905\u092A\u0928\u093E \u0938\u0935\u093E\u0932 \u092A\u0942\u091B\u0947\u0902!',
      '\u091C\u0940 \u092C\u093F\u0932\u094D\u0915\u0941\u0932! \u0915\u091A\u0930\u0947 \u0915\u094B \u092E\u0941\u0916\u094D\u092F \u0930\u0942\u092A \u0938\u0947 5 \u0936\u094D\u0930\u0947\u0923\u093F\u092F\u094B\u0902 \u092E\u0947\u0902 \u092C\u093E\u0902\u091F\u093E \u091C\u093E\u0924\u093E \u0939\u0948: \u092A\u094D\u0932\u093E\u0938\u094D\u091F\u093F\u0915, \u091C\u0948\u0935\u093F\u0915, \u0927\u093E\u0924\u0941, \u0915\u093E\u0902\u091A, \u0914\u0930 \u0916\u0924\u0930\u0928\u093E\u0915 \u0915\u091A\u0930\u093E\u0964 \u092A\u094D\u0930\u0924\u094D\u092F\u0947\u0915 \u0915\u094B \u0905\u0932\u0917-\u0905\u0932\u0917 \u0924\u0930\u0940\u0915\u0947 \u0938\u0947 \u0928\u093F\u092A\u091F\u093E\u0928 \u0915\u0930\u0928\u093E \u091A\u093E\u0939\u093F\u090F\u0964 \u0915\u093F\u0938 \u092C\u093E\u0930\u0947 \u092E\u0947\u0902 \u091C\u093E\u0928\u0928\u093E \u091A\u093E\u0939\u0924\u0947 \u0939\u0948\u0902?',
    ];
    return hindiResponses[Math.floor(Math.random() * hindiResponses.length)];
  }

  if (/^(hi|hello|hey|good morning|good evening|good afternoon|howdy|sup|yo)\b/.test(msg)) {
    if (isFirstMessage) {
      return "Hello! \uD83D\uDC4B I'm your VectorX waste management assistant. I can help you with:\n\n\uD83D\uDD39 How to properly dispose of different waste types\n\uD83D\uDD39 Recycling and composting tips\n\uD83D\uDD39 Reuse ideas for everyday items\n\uD83D\uDD39 E-waste and hazardous waste handling\n\uD83D\uDD39 Reducing your carbon footprint\n\nWhat would you like to know?";
    }
    return "Hey there! \uD83D\uDE0A What can I help you with regarding waste management?";
  }

  if (/^(thanks|thank you|thx|ty|dhanyavaad)/.test(msg)) {
    return "You're welcome! \uD83C\uDF31 Every small step towards proper waste management makes a big difference. Feel free to ask anything else!";
  }

  const topicResponses = {
    'plastic': "Plastic waste is one of the biggest environmental challenges today. Here's how to handle it properly:\n\n\u267B\uFE0F **Sorting**: Check the recycling number (1-7) on the bottom. Types 1 (PET) and 2 (HDPE) are most commonly recycled.\n\uD83D\uDEBF **Clean it**: Rinse containers to remove food residue.\n\u274C **Avoid**: Single-use plastics like straws, bags, and cups.\n\uD83D\uDCA1 **Reuse idea**: Cut plastic bottles to make plant pots, pen holders, or bird feeders.\n\nIn India, many kabadiwallas accept clean plastic for recycling!",

    'recycle|recycling': "Recycling is one of the most impactful things you can do! Here's a quick guide:\n\n\uD83D\uDD35 **Plastic**: Clean, dry, and place in recycling bins\n\uD83D\uDFE2 **Paper/Cardboard**: Flatten boxes, keep dry\n\u26AA **Metal**: Rinse cans, remove labels\n\uD83D\uDFE3 **Glass**: Rinse, sort by color if possible\n\n\uD83D\uDCCA **Did you know?** Recycling 1 aluminum can saves enough energy to power a TV for 3 hours!",

    'compost|composting': "Composting is nature's way of recycling! Here's how to start at home:\n\n\uD83C\uDF3F **Green materials** (nitrogen-rich): Fruit & vegetable scraps, coffee grounds, fresh grass\n\uD83C\uDF42 **Brown materials** (carbon-rich): Dry leaves, cardboard, newspaper, sawdust\n\n**Steps:**\n1. Layer greens and browns in a 1:3 ratio\n2. Keep it moist (like a wrung-out sponge)\n3. Turn it every week for aeration\n4. Ready in 2-3 months!\n\n\uD83D\uDCA1 **Tip**: Avoid meat, dairy, and oily foods in home composting.",

    'organic|food waste|kitchen waste': "Organic waste makes up 50-60% of household waste in India! Here's how to manage it:\n\n\uD83E\uDD6C **Composting**: The best way to handle food scraps at home\n\uD83D\uDC1B **Vermicomposting**: Use earthworms for faster, nutrient-rich compost\n\uD83C\uDF31 **Garden use**: Banana peels and eggshells make excellent plant food\n\nA family of 4 can save \u20B92,000-3,000/month by reducing food waste!",

    'ewaste|e-waste|electronic|phone|laptop|computer|battery': "E-waste is hazardous! \u26A0\uFE0F\n\n**What counts:** Phones, laptops, TVs, batteries, chargers, cables, printers\n\n**How to dispose:**\n1. \uD83C\uDFEA Drop at certified e-waste collection centers\n2. \uD83D\uDCF1 Use manufacturer take-back programs (Apple, Samsung, Dell)\n3. \uD83D\uDD0B Batteries: NEVER throw in regular trash\n4. \uD83D\uDCBE Wipe data before discarding devices\n\nCheck the CPCB website for authorized e-waste recyclers near you.",

    'hazardous|chemical|paint|spray|aerosol': "Hazardous waste requires special handling \u2014 never mix with regular waste! \u26A0\uFE0F\n\n**Examples:** Batteries, paint, pesticides, cleaning chemicals, fluorescent bulbs\n\n**Safe disposal:**\n1. Keep in original containers with labels\n2. Never pour chemicals down drains\n3. Use municipal hazardous waste collection drives\n4. Contact your local pollution control board\n\n**Alternative:** Vinegar and baking soda work great as eco-friendly cleaners!",

    'glass': "Glass is 100% recyclable and can be recycled endlessly without quality loss! \uD83D\uDFE3\n\n**How to recycle:**\n1. Rinse thoroughly\n2. Remove caps and lids\n3. Don't mix with ceramics or window glass\n4. Sort by color if possible\n\n**Reuse ideas:** Mason jar storage, candle holders, flower vases, terrariums\n\n\u267B\uFE0F Recycling glass reduces air pollution by 20% and water pollution by 50%!",

    'metal|aluminum|steel|iron': "Metals are among the most valuable recyclables! \u26AA\n\n**Types:** Aluminum cans, steel/tin cans, foil, copper wire, iron\n\n**Tips:**\n1. Rinse food containers\n2. Crush cans to save space\n3. Keep different metals separate\n4. Sell to kabadiwallas for instant cash!\n\n\uD83D\uDCCA Recycling aluminum saves 95% of the energy needed to make it from raw materials!",

    'carbon|footprint|climate|environment': "Reducing your carbon footprint through waste management is powerful! \uD83C\uDF0D\n\n**Quick wins:**\n\uD83D\uDD04 Recycle \u2014 saves energy vs. making new products\n\uD83C\uDF3F Compost \u2014 prevents methane from landfills\n\uD83D\uDECD\uFE0F Carry reusable bags, bottles, and containers\n\uD83E\uDD57 Reduce food waste \u2014 it's 8-10% of global emissions!\n\n\u2022 Recycling 1 ton of paper = saving 17 trees\n\u2022 A reusable bag replaces 500+ plastic bags",

    'reuse|upcycle|diy': "Reusing items is even better than recycling! Creative ideas:\n\n\uD83E\uDED9 **Glass jars** \u2192 Storage, candle holders, terrariums\n\uD83D\uDC55 **Old clothes** \u2192 Cleaning rags, quilts, tote bags\n\uD83D\uDCE6 **Cardboard** \u2192 Organizers, kids' crafts\n\uD83E\uDD6B **Tin cans** \u2192 Herb planters, pen holders\n\uD83D\uDCF0 **Newspaper** \u2192 Gift wrapping, mulch\n\nThe rule: **Reduce \u2192 Reuse \u2192 Recycle \u2192 Recover \u2192 Landfill** (last resort!)",

    'swachh bharat|india|municipal': "India's waste management is evolving rapidly! \uD83C\uDDEE\uD83C\uDDF3\n\n**Swachh Bharat achievements:**\n\u2022 100,000+ villages declared ODF\n\u2022 Waste processing up from 18% to 75%+\n\nYour role:\n1. Segregate waste into wet (green) and dry (blue) bins\n2. Give recyclables to kabadiwallas\n3. Compost wet waste at home\n4. Report illegal dumping via Swachhata app",

    'what can you do|help|features|about': "I'm your VectorX waste management assistant! I can help with:\n\n\uD83D\uDCF8 **Waste Scanner** \u2014 Photo-identify waste categories\n\uD83D\uDDFA\uFE0F **Recycling Map** \u2014 Find nearby centers\n\uD83D\uDE9B **Pickup Requests** \u2014 Schedule waste collection\n\uD83D\uDCCA **Eco Points** \u2014 Earn rewards\n\nAsk me about disposal, recycling, composting, e-waste, or reducing your footprint!",

    'dispose|throw|get rid|dump': "For proper disposal, it depends on what you have:\n\n\uD83D\uDD35 **Plastic/Paper/Metal/Glass** \u2192 Clean and recycle\n\uD83D\uDFE2 **Food scraps/Garden waste** \u2192 Compost or wet waste bin\n\uD83D\uDD34 **Batteries/Electronics/Chemicals** \u2192 Special collection points\n\uD83D\uDFE1 **Mixed/Unknown** \u2192 Nearest sorting facility\n\nTell me the specific item for detailed instructions!",

    'reduce|zero waste|minimalism': "Waste reduction starts before you throw anything away!\n\n\uD83D\uDED2 **Shopping**: Bring own bags, less packaging\n\uD83C\uDF71 **Food**: Plan meals, store properly, eat leftovers\n\uD83D\uDCA7 **Water**: Refillable bottles instead of packaged\n\u2615 **Coffee**: Reusable cups (many caf\u00E9s give discounts!)\n\uD83D\uDCE7 **Paper**: Go digital for bills and receipts\n\nA single person can reduce 100+ kg of waste per year with simple habits."
  };

  for (const [pattern, response] of Object.entries(topicResponses)) {
    const regex = new RegExp(pattern, 'i');
    if (regex.test(msg)) {
      return response;
    }
  }

  if (msg.includes('bottle') || msg.includes('pet')) {
    return "Bottles can be either plastic or glass \u2014 both recyclable! \uD83D\uDD04\n\n**Plastic (PET):** Rinse, remove cap, crush, and recycle. Reuse as plant waterers!\n**Glass:** Rinse and recycle. Reuse as vases or storage.\n\n\uD83D\uDCA1 PET bottles can be recycled into clothing, bags, and even new bottles!";
  }
  if (msg.includes('paper') || msg.includes('newspaper') || msg.includes('cardboard')) {
    return "Paper and cardboard are easy to recycle! \uD83D\uDCC4\n\n**Do recycle:** Newspapers, magazines, cardboard, office paper\n**Don't:** Wax-coated paper, tissue, paper cups (plastic lining)\n\n\u267B\uFE0F Recycling 1 ton of paper saves 17 trees, 7,000 gallons of water!";
  }
  if (msg.includes('cloth') || msg.includes('textile') || msg.includes('shirt') || msg.includes('jeans')) {
    return "Textile waste is a growing concern! \uD83D\uDC55\n\n1. **Donate**: To NGOs, shelters, or drives\n2. **Upcycle**: Turn jeans into bags, t-shirts into rags\n3. **Textile recycling**: H&M, Zara have take-back programs\n4. **Sell**: On OLX or local thrift stores\n\n\u274C Textiles take 20-200 years to decompose in landfills!";
  }

  if (history && history.length > 2) {
    return "That's a great follow-up! Here are some additional tips:\n\n\uD83D\uDD39 Check your local municipality's waste collection schedule\n\uD83D\uDD39 Separate waste into wet (biodegradable) and dry (recyclable)\n\uD83D\uDD39 Keep hazardous items separate from regular waste\n\uD83D\uDD39 Consider starting a small compost setup\n\nWould you like to know about any specific waste type?";
  }

  return "That's an interesting question! Here's what I can share:\n\n\uD83C\uDF31 **General waste tips:**\n\u2022 Segregate waste at source \u2014 most impactful habit\n\u2022 Wet waste (food) \u2192 compost or green bin\n\u2022 Dry waste (plastic, paper, metal) \u2192 recycling or blue bin\n\u2022 Hazardous waste (batteries, chemicals) \u2192 special collection\n\n\u267B\uFE0F India generates ~62 million tons of waste annually. Proper segregation can reduce landfill burden by 80%!\n\nAsk about any specific item or recycling method!";
}

// ====================== GARBAGE REPORT ======================
router.post('/report', authRequired, upload.single('image'), async (req, res) => {
  try {
    const { description, lat, lng, address } = req.body;
    const reports = readJSON(REPORTS_FILE);
    const users = readJSON(USERS_FILE);

    let imagePath = null;
    if (req.file) {
      const filename = `report_${Date.now()}.jpg`;
      const filepath = path.join(__dirname, '..', 'public', 'uploads', filename);
      fs.writeFileSync(filepath, req.file.buffer);
      imagePath = `/uploads/${filename}`;
    } else if (req.body.image) {
      const base64Data = req.body.image.replace(/^data:image\/\w+;base64,/, '');
      const filename = `report_${Date.now()}.jpg`;
      const filepath = path.join(__dirname, '..', 'public', 'uploads', filename);
      fs.writeFileSync(filepath, Buffer.from(base64Data, 'base64'));
      imagePath = `/uploads/${filename}`;
    }

    const report = {
      id: Date.now().toString(),
      userId: req.session.userId,
      userName: req.session.userName,
      description: description || 'Garbage reported',
      image: imagePath,
      location: { lat: parseFloat(lat) || 0, lng: parseFloat(lng) || 0 },
      address: address || 'Location not provided',
      status: 'Submitted',
      createdAt: new Date().toISOString()
    };

    reports.push(report);
    writeJSON(REPORTS_FILE, reports);

    // Award points
    const userIdx = users.findIndex(u => u.id === req.session.userId);
    if (userIdx !== -1) {
      users[userIdx].points = (users[userIdx].points || 0) + 10;
      users[userIdx].wasteRecycled = (users[userIdx].wasteRecycled || 0) + 0.5;
      users[userIdx].co2Saved = (users[userIdx].co2Saved || 0) + 0.2;
      writeJSON(USERS_FILE, users);
    }

    res.json({ success: true, report, pointsEarned: 10 });
  } catch (error) {
    console.error('Report error:', error);
    res.status(500).json({ success: false, message: 'Failed to submit report' });
  }
});

// ====================== PICKUP SYSTEM ======================
router.post('/pickup', authRequired, (req, res) => {
  try {
    const { wasteType, description, lat, lng, address } = req.body;
    const pickups = readJSON(PICKUPS_FILE);

    const pickup = {
      id: Date.now().toString(),
      userId: req.session.userId,
      userName: req.session.userName,
      wasteType: wasteType || 'Mixed',
      description: description || 'Waste pickup requested',
      location: { lat: parseFloat(lat) || 0, lng: parseFloat(lng) || 0 },
      address: address || 'Location not provided',
      status: 'Requested',
      createdAt: new Date().toISOString()
    };

    pickups.push(pickup);
    writeJSON(PICKUPS_FILE, pickups);

    res.json({ success: true, pickup });
  } catch (error) {
    console.error('Pickup error:', error);
    res.status(500).json({ success: false, message: 'Failed to request pickup' });
  }
});

// Get user pickups
router.get('/pickups', authRequired, (req, res) => {
  const pickups = readJSON(PICKUPS_FILE);
  const userPickups = pickups.filter(p => p.userId === req.session.userId);
  res.json({ success: true, pickups: userPickups });
});

// ====================== LEADERBOARD ======================
router.get('/leaderboard', (req, res) => {
  const users = readJSON(USERS_FILE);
  const leaderboard = users
    .map(u => ({
      id: u.id,
      name: u.name,
      points: u.points || 0,
      wasteRecycled: u.wasteRecycled || 0,
      co2Saved: u.co2Saved || 0
    }))
    .sort((a, b) => b.points - a.points)
    .slice(0, 50);

  res.json({ success: true, leaderboard });
});

// ====================== USER STATS ======================
router.get('/stats', authRequired, (req, res) => {
  const users = readJSON(USERS_FILE);
  const user = users.find(u => u.id === req.session.userId);
  if (!user) return res.status(404).json({ success: false, message: 'User not found' });

  const reports = readJSON(REPORTS_FILE).filter(r => r.userId === req.session.userId);

  res.json({
    success: true,
    stats: {
      name: user.name,
      points: user.points || 0,
      wasteRecycled: (user.wasteRecycled || 0).toFixed(1),
      co2Saved: (user.co2Saved || 0).toFixed(1),
      totalReports: reports.length
    }
  });
});

module.exports = router;
