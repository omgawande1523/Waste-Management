/* ============================================
   VectorX — Main Application JavaScript
   ============================================ */

// ==================== STATE ====================
const state = {
  user: null,
  isAdmin: false,
  currentView: 'dashboard',
  chatHistory: [],
  mapInitialized: false,
  leafletMap: null,
  cameraStream: null,
  scanImageData: null,
  reportImageData: null
};

// ==================== UTILITIES ====================
function $(selector) { return document.querySelector(selector); }
function $$(selector) { return document.querySelectorAll(selector); }

function showToast(message, type = 'info') {
  const toast = $('#toast');
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  setTimeout(() => { toast.className = 'toast hidden'; }, 3000);
}

async function api(url, options = {}) {
  try {
    // Only set Content-Type for non-FormData requests
    // FormData needs fetch to auto-set Content-Type with proper boundary
    const isFormData = options.body instanceof FormData;
    const headers = isFormData
      ? { ...options.headers }
      : { 'Content-Type': 'application/json', ...options.headers };

    const res = await fetch(url, {
      ...options,
      headers
    });
    const data = await res.json();
    return data;
  } catch (err) {
    console.error(`API error [${url}]:`, err);
    return { success: false, message: 'Network error. Please try again.' };
  }
}

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();
  initAuth();
  initNav();
  initTheme();
  initScanner();
  initChat();
  initPickup();
  initReport();
  checkSession();
  initGoogleSignIn();
});

// ==================== THEME ====================
function initTheme() {
  const saved = localStorage.getItem('vectorx-theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  updateThemeIcon(saved);

  $('#theme-toggle').addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('vectorx-theme', next);
    updateThemeIcon(next);
  });
}

function updateThemeIcon(theme) {
  const btn = $('#theme-toggle');
  btn.innerHTML = theme === 'dark'
    ? '<i data-lucide="sun"></i>'
    : '<i data-lucide="moon"></i>';
  lucide.createIcons({ nodes: [btn] });
}

// ==================== AUTH ====================
function initAuth() {
  // Toggle forms
  $('#show-signup').addEventListener('click', (e) => {
    e.preventDefault();
    $$('.auth-form').forEach(f => f.classList.remove('active'));
    $('#signup-form').classList.add('active');
    lucide.createIcons();
  });
  $('#show-login').addEventListener('click', (e) => {
    e.preventDefault();
    $$('.auth-form').forEach(f => f.classList.remove('active'));
    $('#login-form').classList.add('active');
    lucide.createIcons();
  });
  $('#show-admin-login').addEventListener('click', (e) => {
    e.preventDefault();
    $$('.auth-form').forEach(f => f.classList.remove('active'));
    $('#admin-login-form').classList.add('active');
    lucide.createIcons();
  });
  $('#back-to-login').addEventListener('click', (e) => {
    e.preventDefault();
    $$('.auth-form').forEach(f => f.classList.remove('active'));
    $('#login-form').classList.add('active');
    lucide.createIcons();
  });

  // Login
  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = $('#login-email').value.trim();
    const password = $('#login-password').value;
    const btn = $('#login-btn');
    btn.disabled = true;
    btn.querySelector('span').textContent = 'Signing in...';

    const data = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });

    btn.disabled = false;
    btn.querySelector('span').textContent = 'Sign In';

    if (data.success) {
      state.user = data.user;
      showApp();
      showToast('Welcome back, ' + data.user.name + '!', 'success');
    } else {
      showAuthError(data.message);
    }
  });

  // Signup
  $('#signup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = $('#signup-name').value.trim();
    const email = $('#signup-email').value.trim();
    const mobile = $('#signup-mobile').value.trim();
    const password = $('#signup-password').value;
    const btn = $('#signup-btn');
    btn.disabled = true;
    btn.querySelector('span').textContent = 'Creating...';

    const data = await api('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ name, email, mobile, password })
    });

    btn.disabled = false;
    btn.querySelector('span').textContent = 'Create Account';

    if (data.success) {
      state.user = data.user;
      showApp();
      showToast('Welcome to VectorX, ' + data.user.name + '!', 'success');
    } else {
      showAuthError(data.message);
    }
  });

  // Admin login
  $('#admin-login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const password = $('#admin-password').value;
    const btn = $('#admin-login-btn');
    btn.disabled = true;

    const data = await api('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify({ password })
    });

    btn.disabled = false;

    if (data.success) {
      state.isAdmin = true;
      showAdminPanel();
      showToast('Admin access granted', 'success');
    } else {
      showAuthError(data.message);
    }
  });

  // Logout
  $('#logout-btn').addEventListener('click', async () => {
    await api('/api/auth/logout', { method: 'POST' });
    state.user = null;
    stopCamera();
    showAuth();
    showToast('Logged out successfully');
  });

  // Admin logout
  $('#admin-logout-btn').addEventListener('click', async () => {
    await api('/api/admin/logout', { method: 'POST' });
    state.isAdmin = false;
    showAuth();
  });
}

function showAuthError(msg) {
  const el = $('#auth-error');
  el.textContent = msg;
  setTimeout(() => { el.textContent = ''; }, 4000);
}

// ==================== GOOGLE SIGN-IN ====================
async function initGoogleSignIn() {
  try {
    // Fetch the Google Client ID from backend config
    const config = await api('/api/auth/config');
    const clientId = config.googleClientId;

    if (!clientId) {
      console.warn('Google Client ID not configured — Google Sign-In disabled');
      // Hide the Google button containers
      const wrappers = $$('.google-btn-wrapper');
      wrappers.forEach(w => {
        // Also hide the divider right before it
        const prev = w.previousElementSibling;
        if (prev && prev.classList.contains('auth-divider')) prev.style.display = 'none';
        w.style.display = 'none';
      });
      return;
    }

    // Wait for Google Identity Services to load
    function waitForGoogle(retries = 20) {
      if (typeof google !== 'undefined' && google.accounts) {
        renderGoogleButtons(clientId);
      } else if (retries > 0) {
        setTimeout(() => waitForGoogle(retries - 1), 200);
      } else {
        console.warn('Google Identity Services failed to load');
      }
    }
    waitForGoogle();
  } catch (err) {
    console.error('Failed to init Google Sign-In:', err);
  }
}

function renderGoogleButtons(clientId) {
  google.accounts.id.initialize({
    client_id: clientId,
    callback: handleGoogleSignIn,
    auto_select: false,
    cancel_on_tap_outside: true
  });

  // Render in login form
  const loginContainer = document.getElementById('google-signin-btn-login');
  if (loginContainer) {
    google.accounts.id.renderButton(loginContainer, {
      theme: 'outline',
      size: 'large',
      width: '100%',
      text: 'signin_with',
      shape: 'pill',
      logo_alignment: 'center'
    });
  }

  // Render in signup form
  const signupContainer = document.getElementById('google-signin-btn-signup');
  if (signupContainer) {
    google.accounts.id.renderButton(signupContainer, {
      theme: 'outline',
      size: 'large',
      width: '100%',
      text: 'signup_with',
      shape: 'pill',
      logo_alignment: 'center'
    });
  }
}

async function handleGoogleSignIn(response) {
  try {
    const data = await api('/api/auth/google', {
      method: 'POST',
      body: JSON.stringify({ credential: response.credential })
    });

    if (data.success) {
      state.user = data.user;
      showApp();
      showToast('Welcome, ' + data.user.name + '! 🎉', 'success');
    } else {
      showAuthError(data.message || 'Google sign-in failed');
    }
  } catch (err) {
    console.error('Google sign-in error:', err);
    showAuthError('Google sign-in failed. Please try again.');
  }
}
// Make handleGoogleSignIn available globally for GIS callback
window.handleGoogleSignIn = handleGoogleSignIn;

async function checkSession() {
  const data = await api('/api/auth/me');
  if (data.success) {
    state.user = data.user;
    showApp();
  }
}

function showAuth() {
  $('#auth-screen').classList.remove('hidden');
  $('#main-app').classList.add('hidden');
  $('#admin-panel').classList.add('hidden');
  $$('.auth-form').forEach(f => f.classList.remove('active'));
  $('#login-form').classList.add('active');
  lucide.createIcons();
}

function showApp() {
  $('#auth-screen').classList.add('hidden');
  $('#admin-panel').classList.add('hidden');
  $('#main-app').classList.remove('hidden');
  lucide.createIcons();
  loadDashboard();
  loadLeaderboard();
}

function showAdminPanel() {
  $('#auth-screen').classList.add('hidden');
  $('#main-app').classList.add('hidden');
  $('#admin-panel').classList.remove('hidden');
  lucide.createIcons();
  loadAdminData();
}

// ==================== NAVIGATION ====================
function initNav() {
  $$('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
      const view = item.dataset.view;
      navigateTo(view);
    });
  });

  // Quick action buttons
  $$('.action-btn[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => {
      navigateTo(btn.dataset.nav);
    });
  });
}

function navigateTo(viewName) {
  state.currentView = viewName;

  $$('.view').forEach(v => v.classList.remove('active'));
  $(`#view-${viewName}`).classList.add('active');

  $$('.nav-item').forEach(n => n.classList.remove('active'));
  $(`.nav-item[data-view="${viewName}"]`).classList.add('active');

  // Initialize map on first visit
  if (viewName === 'map' && !state.mapInitialized) {
    setTimeout(initMap, 100);
  }

  if (viewName === 'leaderboard') loadLeaderboard();
  if (viewName === 'pickup') loadPickups();

  lucide.createIcons();
  stopCamera(); // Stop camera when navigating away
}

// ==================== DASHBOARD ====================
async function loadDashboard() {
  const data = await api('/api/stats');
  if (data.success) {
    const s = data.stats;
    $('#greeting-text').textContent = `Welcome back, ${s.name}!`;
    $('#dash-points').textContent = s.points;
    $('#dash-recycled').textContent = `${s.wasteRecycled} kg`;
    $('#dash-co2').textContent = `${s.co2Saved} kg`;
    $('#dash-reports').textContent = s.totalReports;
  }
}

// ==================== ADMIN ====================
async function loadAdminData() {
  // Stats
  const statsData = await api('/api/admin/stats');
  if (statsData.success) {
    const s = statsData.stats;
    $('#stat-total-users').textContent = s.totalUsers;
    $('#stat-total-reports').textContent = s.totalReports;
    $('#stat-total-points').textContent = s.totalPoints;
    $('#stat-total-pickups').textContent = s.totalPickups;
  }

  // Users
  const usersData = await api('/api/admin/users');
  if (usersData.success) {
    const tbody = $('#admin-users-table tbody');
    tbody.innerHTML = usersData.users.map(u => `
      <tr>
        <td>${u.name}</td>
        <td>${u.email}</td>
        <td>${u.mobile}</td>
        <td><strong>${u.points}</strong></td>
        <td>${new Date(u.createdAt).toLocaleDateString()}</td>
      </tr>
    `).join('');
  }

  // Reports
  const reportsData = await api('/api/admin/reports');
  if (reportsData.success) {
    const tbody = $('#admin-reports-table tbody');
    tbody.innerHTML = reportsData.reports.map(r => `
      <tr>
        <td>${r.userName || 'Unknown'}</td>
        <td>${r.description}</td>
        <td>${r.address}</td>
        <td><span class="status-badge status-${r.status.toLowerCase().replace(' ', '-')}">${r.status}</span></td>
        <td>${new Date(r.createdAt).toLocaleDateString()}</td>
      </tr>
    `).join('') || '<tr><td colspan="5" style="text-align:center;color:var(--text-muted)">No reports yet</td></tr>';
  }

  // Pickups
  const pickupsData = await api('/api/admin/pickups');
  if (pickupsData.success) {
    const tbody = $('#admin-pickups-table tbody');
    tbody.innerHTML = pickupsData.pickups.map(p => `
      <tr>
        <td>${p.userName || 'Unknown'}</td>
        <td>${p.wasteType}</td>
        <td>${p.address}</td>
        <td><span class="status-badge status-${p.status.toLowerCase().replace(' ', '-')}">${p.status}</span></td>
        <td>
          <select class="admin-action-btn" onchange="updatePickupStatus('${p.id}', this.value)">
            <option value="Requested" ${p.status === 'Requested' ? 'selected' : ''}>Requested</option>
            <option value="In Progress" ${p.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
            <option value="Completed" ${p.status === 'Completed' ? 'selected' : ''}>Completed</option>
          </select>
        </td>
      </tr>
    `).join('') || '<tr><td colspan="5" style="text-align:center;color:var(--text-muted)">No pickup requests yet</td></tr>';
  }

  lucide.createIcons();
}

async function updatePickupStatus(id, status) {
  const data = await api(`/api/admin/pickups/${id}`, {
    method: 'PUT',
    body: JSON.stringify({ status })
  });
  if (data.success) {
    showToast(`Pickup status updated to "${status}"`, 'success');
    loadAdminData();
  }
}

// ==================== SCANNER ====================
function initScanner() {
  // File upload
  $('#scan-file-input').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    compressAndPreview(file);
  });

  // Camera button
  $('#camera-btn').addEventListener('click', async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      state.cameraStream = stream;
      const video = $('#camera-feed');
      video.srcObject = stream;
      video.style.display = 'block';
      $('#preview-image').style.display = 'none';
      $('#scanner-overlay').classList.add('hidden');
      $('#camera-btn').classList.add('hidden');
      $('#capture-btn').classList.remove('hidden');
      $('#analyze-btn').classList.add('hidden');
    } catch (err) {
      showToast('Camera access denied or unavailable', 'error');
    }
  });

  // Capture photo from camera
  $('#capture-btn').addEventListener('click', () => {
    const video = $('#camera-feed');
    const canvas = $('#camera-canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);

    // Compress the captured frame
    canvas.toBlob((blob) => {
      state.scanImageBlob = blob;
      const dataUrl = URL.createObjectURL(blob);
      showScanPreview(dataUrl);
    }, 'image/jpeg', 0.85);

    stopCamera();
  });

  // Analyze button
  $('#analyze-btn').addEventListener('click', () => analyzeImage());
}

// Compress & resize image before sending
function compressAndPreview(file) {
  const img = new Image();
  const url = URL.createObjectURL(file);
  img.onload = () => {
    const canvas = document.createElement('canvas');
    const MAX_DIM = 640; // Resize to max 640px for faster API calls
    let w = img.width, h = img.height;
    if (w > MAX_DIM || h > MAX_DIM) {
      if (w > h) { h = Math.round(h * MAX_DIM / w); w = MAX_DIM; }
      else       { w = Math.round(w * MAX_DIM / h); h = MAX_DIM; }
    }
    canvas.width = w;
    canvas.height = h;
    canvas.getContext('2d').drawImage(img, 0, 0, w, h);
    canvas.toBlob((blob) => {
      state.scanImageBlob = blob;
      showScanPreview(URL.createObjectURL(blob));
    }, 'image/jpeg', 0.85);
    URL.revokeObjectURL(url);
  };
  img.src = url;
}

async function analyzeImage() {
  if (!state.scanImageBlob) return showToast('Please provide an image first', 'error');

  // Show scanning animation
  $('#analyze-btn').classList.add('hidden');
  $('#scan-results').classList.add('hidden');
  const loadEl = $('#scan-loading');
  loadEl.classList.remove('hidden');
  loadEl.innerHTML = `
    <div class="scan-animation">
      <div class="scan-ring"></div>
      <div class="scan-ring delay-1"></div>
      <div class="scan-ring delay-2"></div>
      <i data-lucide="scan" class="scan-anim-icon"></i>
    </div>
    <p class="scan-status-text">Analyzing image with AI...</p>
    <p class="scan-status-sub">Identifying objects & waste category</p>
  `;
  lucide.createIcons({ nodes: [loadEl] });

  // Send as binary FormData (not JSON base64)
  const formData = new FormData();
  formData.append('image', state.scanImageBlob, 'scan.jpg');

  try {
    const res = await fetch('/api/scan', { method: 'POST', body: formData });
    const data = await res.json();

    loadEl.classList.add('hidden');

    if (data.modelLoading) {
      // Model is cold-starting — show retry
      showToast(data.message, 'info');
      $('#analyze-btn').classList.remove('hidden');
      $('#analyze-btn').innerHTML = '<i data-lucide="refresh-cw"></i><span>Retry Analysis</span>';
      lucide.createIcons({ nodes: [$('#analyze-btn')] });
      return;
    }

    if (data.success) {
      renderScanResults(data.result, data.isFallback);
    } else {
      showToast(data.message || 'Scan failed', 'error');
      $('#analyze-btn').classList.remove('hidden');
    }
  } catch (err) {
    loadEl.classList.add('hidden');
    showToast('Network error. Please try again.', 'error');
    $('#analyze-btn').classList.remove('hidden');
  }
}

function showScanPreview(url) {
  const img = $('#preview-image');
  img.src = url;
  img.style.display = 'block';
  $('#camera-feed').style.display = 'none';
  $('#scanner-overlay').classList.add('hidden');
  $('#camera-btn').classList.remove('hidden');
  $('#capture-btn').classList.add('hidden');
  $('#analyze-btn').classList.remove('hidden');
  $('#analyze-btn').innerHTML = '<i data-lucide="zap"></i><span>Analyze with AI</span>';
  lucide.createIcons({ nodes: [$('#analyze-btn')] });
  $('#scan-results').classList.add('hidden');
}

function renderScanResults(result, isFallback) {
  const categoryClass = `category-${result.category.toLowerCase()}`;

  // Low confidence warning
  const lowConfWarning = result.isLowConfidence
    ? `<div class="scan-warning"><i data-lucide="alert-triangle"></i><span>Low confidence detection — this is our best guess. Consider verifying manually.</span></div>`
    : '';

  // Top predictions section
  let predictionsHtml = '';
  if (result.topPredictions && result.topPredictions.length > 1) {
    predictionsHtml = `
      <div class="scan-detail">
        <h4>Top Predictions</h4>
        <div class="predictions-grid">
          ${result.topPredictions.map(p => `
            <div class="prediction-chip">
              <span class="pred-emoji">${p.emoji}</span>
              <div class="pred-info">
                <span class="pred-label">${p.label}</span>
                <span class="pred-conf">${p.confidence}</span>
              </div>
              <span class="pred-cat">${p.category}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  const html = `
    ${isFallback ? '<div class="scan-demo-badge"><i data-lucide="zap"></i> Demo Mode — add HuggingFace API key for real AI</div>' : ''}
    ${lowConfWarning}
    <div class="scan-result-header">
      <div class="category-icon ${categoryClass}">${result.categoryEmoji || '🟡'}</div>
      <div>
        <h3>${result.detectedObject}</h3>
        <div class="scan-meta">
          <span class="confidence-badge">${result.confidence}</span>
          <span class="category-badge ${categoryClass}">${result.category}</span>
        </div>
      </div>
    </div>
    ${predictionsHtml}
    <div class="scan-detail">
      <h4>♻️ Disposal Instructions</h4>
      <p>${result.disposal}</p>
    </div>
    <div class="scan-detail">
      <h4>💡 Reuse Ideas</h4>
      <ul>${result.reuseSuggestions.map(s => `<li>${s}</li>`).join('')}</ul>
    </div>
  `;

  const el = $('#scan-results');
  el.innerHTML = html;
  el.classList.remove('hidden');
  $('#analyze-btn').classList.remove('hidden');
  $('#analyze-btn').innerHTML = '<i data-lucide="refresh-cw"></i><span>Scan Again</span>';
  lucide.createIcons();
}

function stopCamera() {
  if (state.cameraStream) {
    state.cameraStream.getTracks().forEach(t => t.stop());
    state.cameraStream = null;
    const video = $('#camera-feed');
    if (video) { video.srcObject = null; video.style.display = 'none'; }
    const camBtn = $('#camera-btn');
    if (camBtn) camBtn.classList.remove('hidden');
    const capBtn = $('#capture-btn');
    if (capBtn) capBtn.classList.add('hidden');
  }
  // Also stop report camera
  if (state.reportCameraStream) {
    state.reportCameraStream.getTracks().forEach(t => t.stop());
    state.reportCameraStream = null;
    const rv = $('#report-camera-feed');
    if (rv) { rv.srcObject = null; rv.style.display = 'none'; }
    const rcap = $('#report-capture-btn');
    if (rcap) rcap.classList.add('hidden');
  }
}

// ==================== CHAT ====================
function initChat() {
  const form = $('#chat-form');
  const input = $('#chat-input');
  const sendBtn = form.querySelector('.btn-send');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = input.value.trim();
    if (!message) return;

    // Disable input during processing
    input.value = '';
    input.disabled = true;
    sendBtn.disabled = true;

    appendChatMessage('user', message);
    state.chatHistory.push({ role: 'user', content: message });

    // Trim history to last 10 messages for memory management
    if (state.chatHistory.length > 10) {
      state.chatHistory = state.chatHistory.slice(-10);
    }

    // Show typing indicator
    const typingEl = appendTypingIndicator();

    try {
      const data = await api('/api/chat', {
        method: 'POST',
        body: JSON.stringify({ message, history: state.chatHistory })
      });

      typingEl.remove();

      if (data.success) {
        appendChatMessage('bot', data.reply, true);
        state.chatHistory.push({ role: 'assistant', content: data.reply });
      } else {
        appendChatMessage('bot', 'Sorry, I\'m having trouble right now. Please try again! 🔄');
      }
    } catch (err) {
      typingEl.remove();
      appendChatMessage('bot', 'Network error occurred. Please check your connection and try again.');
    }

    // Re-enable input
    input.disabled = false;
    sendBtn.disabled = false;
    input.focus();
  });
}

function appendChatMessage(role, text, useTypingEffect = false) {
  const container = $('#chat-messages');
  const div = document.createElement('div');
  div.className = `chat-message ${role}`;
  const icon = role === 'bot' ? 'bot' : 'user';

  if (role === 'bot' && useTypingEffect) {
    // Typing effect for bot messages
    div.innerHTML = `
      <div class="chat-avatar"><i data-lucide="${icon}"></i></div>
      <div class="chat-bubble"><span class="typing-target"></span><span class="typing-cursor">|</span></div>
    `;
    container.appendChild(div);
    lucide.createIcons({ nodes: [div] });
    container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });

    const target = div.querySelector('.typing-target');
    const cursor = div.querySelector('.typing-cursor');
    const formatted = formatChatText(text);
    let i = 0;
    // Type raw text for display, batch characters for speed
    const plainText = text;
    const speed = Math.max(8, Math.min(25, 1200 / plainText.length));

    function typeNext() {
      if (i < plainText.length) {
        // Add a few characters at once for longer messages
        const chunk = plainText.slice(i, i + 2);
        i += 2;
        target.innerHTML = formatChatText(plainText.slice(0, i));
        container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
        setTimeout(typeNext, speed);
      } else {
        // Done typing — remove cursor
        if (cursor) cursor.remove();
        target.innerHTML = formatted;
      }
    }
    typeNext();
  } else {
    div.innerHTML = `
      <div class="chat-avatar"><i data-lucide="${icon}"></i></div>
      <div class="chat-bubble">${formatChatText(text)}</div>
    `;
    container.appendChild(div);
    lucide.createIcons({ nodes: [div] });
  }

  // Smooth scroll to bottom
  container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
}

function appendTypingIndicator() {
  const container = $('#chat-messages');
  const div = document.createElement('div');
  div.className = 'chat-message bot typing-indicator';
  div.innerHTML = `
    <div class="chat-avatar"><i data-lucide="bot"></i></div>
    <div class="chat-bubble">
      <div class="chat-typing"><span></span><span></span><span></span></div>
    </div>
  `;
  container.appendChild(div);
  container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
  lucide.createIcons({ nodes: [div] });
  return div;
}

function formatChatText(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>')
    .replace(/• /g, '&bull; ')
    .replace(/🔹 /g, '<span style="color:var(--accent-primary)">▸</span> ');
}

// ==================== MAP ====================

// VectorX Smart Waste Segregation Dustbin Locations — Nagpur
const VECTORX_DUSTBINS = [
  {
    name: 'VectorX Smart Dustbin — Dharampeth',
    address: 'Near Dharampeth Science College, Dharampeth, Nagpur',
    lat: 21.1458,
    lng: 79.0660,
    types: ['Plastic', 'Organic', 'Metal', 'Glass', 'Hazardous']
  },
  {
    name: 'VectorX Smart Dustbin — Sitabuldi',
    address: 'Sitabuldi Main Road, near Variety Square, Nagpur',
    lat: 21.1430,
    lng: 79.0840,
    types: ['Plastic', 'Organic', 'Metal', 'Glass']
  },
  {
    name: 'VectorX Smart Dustbin — Sadar',
    address: 'Sadar Bazaar, near Jaistambh Square, Nagpur',
    lat: 21.1550,
    lng: 79.0900,
    types: ['Plastic', 'Organic', 'Metal', 'E-Waste']
  },
  {
    name: 'VectorX Smart Dustbin — Futala Lake',
    address: 'Futala Lake Garden, Civil Lines, Nagpur',
    lat: 21.1600,
    lng: 79.0520,
    types: ['Plastic', 'Organic', 'Glass']
  },
  {
    name: 'VectorX Smart Dustbin — Ramdaspeth',
    address: 'Ramdaspeth, near Lokmat Square, Nagpur',
    lat: 21.1370,
    lng: 79.0750,
    types: ['Plastic', 'Organic', 'Metal', 'Glass', 'Hazardous', 'E-Waste']
  }
];

function createDustbinIcon() {
  return L.divIcon({
    html: `<div style="
      width: 36px; height: 36px;
      background: linear-gradient(135deg, #00f5a0, #00d9f5);
      border-radius: 50%;
      border: 3px solid #fff;
      box-shadow: 0 0 14px rgba(0, 245, 160, 0.5), 0 2px 8px rgba(0,0,0,0.3);
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; line-height: 1;
      animation: dustbinPulse 2s ease-in-out infinite;
    ">🗑️</div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -20],
    className: 'dustbin-marker'
  });
}

function addDustbinMarkers(map) {
  const dustbinIcon = createDustbinIcon();

  VECTORX_DUSTBINS.forEach((bin, index) => {
    const typeBadges = bin.types.map(t => {
      const colors = {
        'Plastic': '#3b82f6', 'Organic': '#10b981', 'Metal': '#9ca3af',
        'Glass': '#8b5cf6', 'Hazardous': '#f43f5e', 'E-Waste': '#f59e0b'
      };
      return `<span style="
        display:inline-block; padding:2px 8px; margin:2px;
        background:${colors[t] || '#666'}22; color:${colors[t] || '#666'};
        border:1px solid ${colors[t] || '#666'}44;
        border-radius:12px; font-size:0.7rem; font-weight:600;
      ">${t}</span>`;
    }).join('');

    const btnId = `directions-btn-${index}`;

    const popup = `
      <div style="font-family:'Inter',sans-serif; min-width:220px; padding:4px;">
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
          <span style="font-size:1.4rem;">🗑️</span>
          <strong style="font-size:0.95rem; color:#0f172a;">${bin.name}</strong>
        </div>
        <p style="font-size:0.8rem; color:#64748b; margin:0 0 8px;">${bin.address}</p>
        <div style="margin-bottom:10px;">${typeBadges}</div>
        <button id="${btnId}" onclick="openDirections(${bin.lat}, ${bin.lng})"
           style="
            display:inline-flex; align-items:center; gap:6px;
            padding:8px 16px; background:linear-gradient(135deg,#00f5a0,#00d9f5);
            color:#0a0e1a; font-weight:600; font-size:0.85rem;
            border-radius:20px; text-decoration:none; border:none; cursor:pointer;
            box-shadow: 0 2px 8px rgba(0,245,160,0.3);
          ">
          📍 Get Directions
        </button>
      </div>
    `;

    L.marker([bin.lat, bin.lng], { icon: dustbinIcon })
      .addTo(map)
      .bindPopup(popup, { maxWidth: 300 });
  });
}

// Open Google Maps directions from user's current location to destination
function openDirections(destLat, destLng) {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const url = `https://www.google.com/maps/dir/?api=1&origin=${latitude},${longitude}&destination=${destLat},${destLng}&travelmode=driving`;
        window.open(url, '_blank');
      },
      () => {
        // Fallback: open without origin, let Google Maps detect
        const url = `https://www.google.com/maps/dir/?api=1&origin=My+Location&destination=${destLat},${destLng}&travelmode=driving`;
        window.open(url, '_blank');
      },
      { enableHighAccuracy: true, timeout: 5000 }
    );
  } else {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${destLat},${destLng}&travelmode=driving`;
    window.open(url, '_blank');
  }
}
window.openDirections = openDirections;
}

function initMap() {
  if (state.mapInitialized) return;
  state.mapInitialized = true;

  const defaultLat = 21.1480;
  const defaultLng = 79.0750;

  const map = L.map('leaflet-map').setView([defaultLat, defaultLng], 13);
  state.leafletMap = map;

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19
  }).addTo(map);

  // Add VectorX Smart Dustbin markers
  addDustbinMarkers(map);

  // Fetch recycling centers from Overpass API
  fetchRecyclingCenters(defaultLat, defaultLng, map);

  // Locate button
  $('#locate-btn').addEventListener('click', () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          map.setView([latitude, longitude], 14);

          L.marker([latitude, longitude], {
            icon: L.divIcon({
              html: '<div style="width:14px;height:14px;background:#00f5a0;border-radius:50%;border:3px solid #fff;box-shadow:0 0 10px rgba(0,245,160,0.5);"></div>',
              iconSize: [14, 14],
              className: ''
            })
          }).addTo(map).bindPopup('<strong>You are here</strong>');

          fetchRecyclingCenters(latitude, longitude, map);
        },
        () => showToast('Could not get your location', 'error')
      );
    }
  });

  // Fix map rendering after tab switch
  setTimeout(() => map.invalidateSize(), 200);
}

async function fetchRecyclingCenters(lat, lng, map) {
  const query = `
    [out:json][timeout:10];
    (
      node["amenity"="recycling"](around:5000,${lat},${lng});
      node["amenity"="waste_disposal"](around:5000,${lat},${lng});
      node["amenity"="waste_transfer_station"](around:5000,${lat},${lng});
      node["recycling_type"="centre"](around:5000,${lat},${lng});
    );
    out body 30;
  `;

  try {
    const res = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST',
      body: `data=${encodeURIComponent(query)}`
    });
    const data = await res.json();

    if (data.elements && data.elements.length > 0) {
      data.elements.forEach(el => {
        const name = el.tags?.name || 'Recycling Center';
        const type = el.tags?.amenity || 'recycling';
        const marker = L.marker([el.lat, el.lon]).addTo(map);
        marker.bindPopup(`
          <div style="font-family:Inter,sans-serif;">
            <strong>${name}</strong><br>
            <em style="color:#666;">${type.replace('_', ' ')}</em><br>
            <a href="https://www.google.com/maps/dir/?api=1&destination=${el.lat},${el.lon}"
               target="_blank" rel="noopener"
               style="color:#00f5a0;font-weight:600;">
              📍 Get Directions
            </a>
          </div>
        `);
      });
      showToast(`Found ${data.elements.length} nearby centers`, 'success');
    } else {
      showToast('No recycling centers found nearby', 'info');
    }
  } catch (err) {
    console.error('Overpass API error:', err);
    // Add demo markers as fallback
    const demoPoints = [
      { lat: lat + 0.01, lng: lng + 0.01, name: 'Green Recycling Hub' },
      { lat: lat - 0.01, lng: lng + 0.005, name: 'City Waste Collection' },
      { lat: lat + 0.005, lng: lng - 0.01, name: 'E-Waste Disposal Center' }
    ];
    demoPoints.forEach(p => {
      L.marker([p.lat, p.lng]).addTo(map).bindPopup(`
        <div style="font-family:Inter,sans-serif;">
          <strong>${p.name}</strong><br>
          <em style="color:#666;">Demo location</em><br>
          <a href="https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}"
             target="_blank" rel="noopener"
             style="color:#00f5a0;font-weight:600;">
            📍 Get Directions
          </a>
        </div>
      `);
    });
  }
}

// ==================== PICKUP ====================
function initPickup() {
  // Location detect
  $('#pickup-locate-btn').addEventListener('click', () => {
    detectLocation('pickup');
  });

  // Submit
  $('#pickup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const wasteType = $('#pickup-waste-type').value;
    const description = $('#pickup-description').value;
    const lat = $('#pickup-lat').value;
    const lng = $('#pickup-lng').value;
    const address = $('#pickup-address').value;

    if (!wasteType) return showToast('Please select waste type', 'error');

    const data = await api('/api/pickup', {
      method: 'POST',
      body: JSON.stringify({ wasteType, description, lat, lng, address })
    });

    if (data.success) {
      showToast('Pickup requested successfully!', 'success');
      $('#pickup-form').reset();
      $('#pickup-address').value = '';
      loadPickups();
    } else {
      showToast(data.message || 'Failed to request pickup', 'error');
    }
  });
}

async function loadPickups() {
  const data = await api('/api/pickups');
  if (data.success) {
    const list = $('#pickup-list');
    if (data.pickups.length === 0) {
      list.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:20px;">No pickup requests yet</p>';
      return;
    }
    list.innerHTML = data.pickups.reverse().map(p => `
      <div class="pickup-card">
        <div class="pickup-card-info">
          <h4>${p.wasteType}</h4>
          <p>${p.address || 'Location pending'}</p>
          <p>${new Date(p.createdAt).toLocaleDateString()}</p>
        </div>
        <span class="status-badge status-${p.status.toLowerCase().replace(' ', '-')}">${p.status}</span>
      </div>
    `).join('');
  }
}

// ==================== REPORT ====================
function initReport() {
  // File upload
  $('#report-file-input').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      state.reportImageData = ev.target.result;
      const img = $('#report-preview-img');
      img.src = ev.target.result;
      img.style.display = 'block';
      $('#report-image-preview').querySelector('i').style.display = 'none';
      $('#report-image-preview').querySelector('p').style.display = 'none';
    };
    reader.readAsDataURL(file);
  });

  // Camera
  $('#report-camera-btn').addEventListener('click', async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      state.reportCameraStream = stream;
      const video = $('#report-camera-feed');
      video.srcObject = stream;
      video.style.display = 'block';
      await video.play(); // Explicitly start playback (required by many browsers)

      // Hide preview image if one was showing
      $('#report-preview-img').style.display = 'none';
      const iconEl = $('#report-image-preview').querySelector('i');
      const pEl = $('#report-image-preview').querySelector('p');
      if (iconEl) iconEl.style.display = 'none';
      if (pEl) pEl.style.display = 'none';

      // Show capture button, hide camera button
      $('#report-capture-btn').classList.remove('hidden');
      $('#report-camera-btn').classList.add('hidden');
    } catch (err) {
      console.error('Report camera error:', err);
      showToast('Camera not available: ' + (err.message || 'Access denied'), 'error');
    }
  });

  // Capture
  $('#report-capture-btn').addEventListener('click', () => {
    const video = $('#report-camera-feed');
    const canvas = $('#report-camera-canvas');

    // Ensure video has valid dimensions
    if (!video.videoWidth || !video.videoHeight) {
      showToast('Camera not ready yet. Please wait a moment.', 'error');
      return;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);

    state.reportImageData = dataUrl;
    const img = $('#report-preview-img');
    img.src = dataUrl;
    img.style.display = 'block';

    // Restore icon/text visibility state (hidden since we have an image now)
    // They stay hidden because we're showing the captured image

    // Stop camera
    if (state.reportCameraStream) {
      state.reportCameraStream.getTracks().forEach(t => t.stop());
      state.reportCameraStream = null;
    }
    video.srcObject = null;
    video.style.display = 'none';
    $('#report-capture-btn').classList.add('hidden');
    $('#report-camera-btn').classList.remove('hidden');

    showToast('Photo captured!', 'success');
  });

  // Location
  $('#report-locate-btn').addEventListener('click', () => {
    detectLocation('report');
  });

  // Submit
  $('#report-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const description = $('#report-description').value;
    const lat = $('#report-lat').value;
    const lng = $('#report-lng').value;
    const address = $('#report-address').value;

    if (!state.reportImageData && !$('#report-file-input').files[0]) {
      return showToast('Please provide an image', 'error');
    }

    const data = await api('/api/report', {
      method: 'POST',
      body: JSON.stringify({
        image: state.reportImageData,
        description,
        lat, lng, address
      })
    });

    if (data.success) {
      showToast(`Report submitted! +${data.pointsEarned} eco points 🌟`, 'success');
      $('#report-form').reset();
      state.reportImageData = null;
      const img = $('#report-preview-img');
      img.style.display = 'none';
      const iconEl = $('#report-image-preview').querySelector('i');
      const pEl = $('#report-image-preview').querySelector('p');
      if (iconEl) iconEl.style.display = '';
      if (pEl) pEl.style.display = '';
      loadDashboard();
    } else {
      showToast(data.message || 'Failed to submit report', 'error');
    }
  });
}

// ==================== LEADERBOARD ====================
async function loadLeaderboard() {
  const data = await api('/api/leaderboard');
  if (data.success) {
    const list = $('#leaderboard-list');
    if (data.leaderboard.length === 0) {
      list.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:40px;">No users yet. Be the first to earn points!</p>';
      return;
    }
    list.innerHTML = data.leaderboard.map((u, i) => {
      const rank = i + 1;
      const rankClass = rank <= 3 ? `rank-${rank}` : '';
      const isCurrent = state.user && u.id === state.user.id;
      return `
        <div class="leader-card ${isCurrent ? 'current-user' : ''}">
          <div class="leader-rank ${rankClass}">${rank}</div>
          <div class="leader-info">
            <h4>${u.name} ${isCurrent ? '(You)' : ''}</h4>
            <p>${u.wasteRecycled} kg recycled · ${u.co2Saved} kg CO₂ saved</p>
          </div>
          <div class="leader-points">
            <span class="pts-value">${u.points}</span>
            <span class="pts-label">pts</span>
          </div>
        </div>
      `;
    }).join('');
  }
}

// ==================== GEOLOCATION HELPER ====================
function detectLocation(prefix) {
  if (!navigator.geolocation) {
    return showToast('Geolocation not supported', 'error');
  }

  showToast('Detecting location...', 'info');

  navigator.geolocation.getCurrentPosition(
    async (pos) => {
      const { latitude, longitude } = pos.coords;
      $(`#${prefix}-lat`).value = latitude;
      $(`#${prefix}-lng`).value = longitude;

      // Reverse geocode
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
        const data = await res.json();
        const address = data.display_name || `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
        $(`#${prefix}-address`).value = address;
        showToast('Location detected!', 'success');
      } catch {
        $(`#${prefix}-address`).value = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
        showToast('Location set (address lookup failed)', 'info');
      }
    },
    () => showToast('Could not detect location', 'error'),
    { enableHighAccuracy: true, timeout: 10000 }
  );
}

// Make this available globally for admin panel inline handler
window.updatePickupStatus = updatePickupStatus;
